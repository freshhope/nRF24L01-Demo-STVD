/**
  ******************************************************************************
  * @author  ��ҫ�Ƽ� ASHINING
  * @version V3.0
  * @date    2016-10-08
  * @brief   ������C�ļ�
  ******************************************************************************
  * @attention
  *
  * ����	:	http://www.ashining.com
  * �Ա�	:	https://shop105912646.taobao.com
  * ����Ͱ�:	https://cdzeyao.1688.com
  ******************************************************************************
  */
  


#include "main.h"


const char *g_Ashining = "ashining";
uint8_t g_TxMode = 0, g_UartRxFlag = 0;
uint8_t g_UartRxBuffer[ 100 ] = { 0 };
uint8_t g_RF24L01RxBuffer[ 32 ] = { 1,2,3,4,5,6,7,8,9 }; 



/**
  * @brief :������ 
  * @param :��
  * @note  :��
  * @retval:��
  */
void main( void )
{
	uint8_t i = 0;

	//���ڳ�ʼ��
	drv_uart_init( 9600 );
	
	//LED��ʼ��
	drv_led_init( );
	
	//SPI��ʼ��
	drv_spi_init( );

	//RF24L01��ʼ��
	NRF24L01_Gpio_Init( );
	NRF24L01_check( );
	RF24L01_Init( );
	
	led_red_off( );
	led_green_off( );
	for( i = 0; i < 6; i++ )
	{
		led_red_flashing( );
		led_green_flashing( );
		drv_delay_ms( 500 );
	}
	
#ifdef	__RF24L01_TX_TEST__		
//=========================================================================================//	
//*****************************************************************************************//
//************************************* ���� **********************************************//
//*****************************************************************************************//
//=========================================================================================//	
	
	//������ʼ��
	drv_button_init( );
	
	RF24L01_Set_Mode( MODE_TX );		//����ģʽ
	
	while( 1 )	
	{
		//ģʽ�л�
		if( BUTOTN_PRESS_DOWN == drv_button_check( ))
		{
			g_TxMode = 1 - g_TxMode;		//ģʽ���� TX_MODE_1( 0 ),TX_MODE_2( 1 )֮���л�
			
			//״̬��ʾ����
			led_green_off( );
			led_red_off( );
			
			if( TX_MODE_1 == g_TxMode )
			{
				for( i = 0; i < 6; i++ )		
				{
					led_red_flashing( );	//�̶�����ģʽ�������˸3��
					drv_delay_ms( 500 );		
				}
			}
			else
			{
				for( i = 0; i < 6; i++ )
				{
					led_green_flashing( );	//���ڷ���ģʽ���̵���˸3��
					drv_delay_ms( 500 );
				}
			}
		}
		
		//����
		if( TX_MODE_1 == g_TxMode )
		{
			NRF24L01_TxPacket( (uint8_t *)g_Ashining, 8 );		//ģʽ1���͹̶��ַ�,1Sһ��
			drv_delay_ms( 1000 );		
			led_red_flashing( );			
		}
		else
		{	
			//��ѯ��������
			i = drv_uart_rx_bytes( g_UartRxBuffer );
			
			if( 0 != i )
			{
				NRF24L01_TxPacket( g_UartRxBuffer, i );
				led_red_flashing( );
			}
		}
	}
	
#else		
//=========================================================================================//	
//*****************************************************************************************//
//************************************* ���� **********************************************//
//*****************************************************************************************//
//=========================================================================================//	
	
	RF24L01_Set_Mode( MODE_RX );		//����ģʽ	
	
	while( 1 )
	{
		NRF24L01_RxPacket( g_RF24L01RxBuffer );		//�����ֽ�
		i = NRF24L01_Read_Reg( R_RX_PL_WID );		//�����ֽڸ���
		if( 0 != i )
		{
			led_green_flashing( );
			drv_uart_tx_bytes( g_RF24L01RxBuffer,i );	//������յ����ֽ�
			
		}
	}
		

#endif
}